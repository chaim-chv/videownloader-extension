chrome.tabs.onActivated.addListener(function(info){
    chrome.tabs.get(info.tabId, function(change){
        if(change.url == undefined){
            chrome.browserAction.setIcon({path: 'icons/videownload-bad.png', tabId: info.tabId});
            console.log('undefined');
        }
        else if(change.url.match('^(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/.+$') == null){
            chrome.browserAction.setIcon({path: 'icons/videownload-bad.png', tabId: info.tabId});
            console.log('not matching');
        }
        else{
            chrome.browserAction.setIcon({path: 'icons/videownload.png', tabId: info.tabId});
            console.log('matched');
        }
    });
});
chrome.tabs.onUpdated.addListener(function (tabId, change, tab){
    if(change.url == undefined){
        return;
    }
    else if(('^(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/.+$') == null){
        chrome.browserAction.setIcon({path: 'icons/videownload-bad.png', tabId: tabId});
        console.log('not matching');
    }
    else{
        chrome.browserAction.setIcon({path: '/icons/videownload.png', tabId: tabId});
        console.log('matched');
    }
});