var video_id = window.location.search.split('v=')[1];
var somefix = video_id.indexOf('&');
if (somefix != -1) {
  video_id = video_id.substring(0, somefix);
};
var dlink = ("https://videownload.ml/download/https://youtu.be/" + video_id);
function gotodown(dlink) { var win = window.open(dlink, '_blank'); win.focus(); };
gotodown(dlink)