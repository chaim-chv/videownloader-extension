chrome.browserAction.onClicked.addListener(function(tab) {
    chrome.tabs.query({active: true, currentWindow: true, lastFocusedWindow: true}, 
        function (listabs) {
        var activeTab = listabs[0].url;
       var check = new RegExp('^(https?\:\/\/)?(www\.youtube\.com|youtu\.?be|videownload.ml)\/.+$');
if (check.test(activeTab)) {
    var down = "down"
    chrome.notifications.create(down, {
     "type": "basic",
     "title": "הורדה מיוטיוב",
     "message": "כבר מוריד...",
     "iconUrl": chrome.runtime.getURL("icons/down.png")
     });
     chrome.tabs.executeScript(null, {file: "action.js"});
    }
else {
    var noclip = "noclip"
    chrome.notifications.create(noclip, {
     "type": "basic",
     "title": "הורדה מיוטיוב",
     "message": "לא נמצא סרטון...",
     "iconUrl": chrome.runtime.getURL("icons/error.png")
    });
}
});
chrome.contextMenus.create({
    title: "נוצר על ידי chv",
    contexts: ["browser_action"],
});
})